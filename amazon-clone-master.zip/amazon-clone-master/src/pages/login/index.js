import React from 'react';

function LoginPage() {
  return <div>Login Page</div>;
}

export default LoginPage;
